import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LaptopsPage extends AbstractPage{

    @FindBy(xpath = "//a[normalize-space()='Laptops & Notebooks']")
    private WebElement laptopsButton;

    @FindBy(xpath = "//a[normalize-space()='Show All Laptops & Notebooks']")
    private WebElement showAllButton;

    @FindBy(xpath = "//img[@title='HP LP3065']")
    private WebElement firstLaptop;

    @FindBy(xpath = "//img[@title='MacBook']")
    private WebElement secondLaptop;

    @FindBy(xpath = "//img[@title='MacBook Air']")
    private WebElement thirdLaptop;

    @FindBy(xpath = "//img[@title='MacBook Pro']")
    private WebElement fourthLaptop;

    @FindBy(xpath = "//img[@title='Sony VAIO']")
    private WebElement fifthLaptop;

    public LaptopsPage(WebDriver driver) {
        super(driver);
    }
    public void clickLaptopsButton(){
        laptopsButton.click();
    }
    public void clickShowAllButton(){
        showAllButton.click();
    }
    public void clickFirstLaptop(){
        firstLaptop.click();
    }
    public void clickSecondLaptop(){
        secondLaptop.click();
    }
    public void clickThirdLaptop(){
        thirdLaptop.click();
    }
    public void clickFourthLaptop(){
        fourthLaptop.click();
    }
    public void clickFifthlaptop(){
        fifthLaptop.click();
    }
}
