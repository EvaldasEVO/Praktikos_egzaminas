import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PhonesPage extends AbstractPage {

    @FindBy(xpath = "//a[normalize-space()='Phones & PDAs']")
    private WebElement phonesButton;

    @FindBy(xpath = "//img[@title='HTC Touch HD']")
    private WebElement firstProduct;

    @FindBy(xpath = "//img[@title='iPhone']")
    private WebElement secondProduct;

    @FindBy(xpath = "//img[@title='Palm Treo Pro']")
    private WebElement thirdProduct;

    public PhonesPage (WebDriver driver){
        super (driver);
    }
    public void clickPhonesButton(){
        phonesButton.click();
    }
    public void clickFirstProduct(){
        firstProduct.click();
    }
    public void clickSecondProduct(){
        secondProduct.click();
    }
    public void clickThirdProduct(){
        thirdProduct.click();
    }
}

