import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;

public class LaptopsPageTest extends BaseTest{
    LaptopsPage laptopsPage = new LaptopsPage(driver);


    @Test
    public void productInStock(){
        laptopsPage.clickLaptopsButton();
        laptopsPage.clickShowAllButton();
        laptopsPage.clickFirstLaptop();
        Assert.assertEquals("skiltyje tabX prekes compX pasiekiamumas yra 'Out Of Stock', skiltyje tabY prekes compY pasiekiamumas yra 'Pre-Order', nors visu prekiu statuso tikimasi 'In Stock'", "In Stock", "In Stock");
        driver.findElement(By.cssSelector("body div[id='product-product'] ul[class='breadcrumb'] li:nth-child(2) a:nth-child(1)")).click();
        laptopsPage.clickSecondLaptop();
        Assert.assertEquals("skiltyje tabX prekes compX pasiekiamumas yra 'Out Of Stock', skiltyje tabY prekes compY pasiekiamumas yra 'Pre-Order', nors visu prekiu statuso tikimasi 'In Stock'", "In Stock", "Out Of Stock");
        driver.findElement(By.cssSelector("body div[id='product-product'] ul[class='breadcrumb'] li:nth-child(2) a:nth-child(1)")).click();
        laptopsPage.clickThirdLaptop();
        Assert.assertEquals("skiltyje tabX prekes compX pasiekiamumas yra 'Out Of Stock', skiltyje tabY prekes compY pasiekiamumas yra 'Pre-Order', nors visu prekiu statuso tikimasi 'In Stock'", "In Stock", "Out Of Stock");
        driver.findElement(By.cssSelector("body div[id='product-product'] ul[class='breadcrumb'] li:nth-child(2) a:nth-child(1)")).click();
        laptopsPage.clickFourthLaptop();
        Assert.assertEquals("skiltyje tabX prekes compX pasiekiamumas yra 'Out Of Stock', skiltyje tabY prekes compY pasiekiamumas yra 'Pre-Order', nors visu prekiu statuso tikimasi 'In Stock'", "In Stock", "Out Of Stock");
        driver.findElement(By.cssSelector("body div[id='product-product'] ul[class='breadcrumb'] li:nth-child(2) a:nth-child(1)")).click();
        laptopsPage.clickFifthlaptop();
        Assert.assertEquals("skiltyje tabX prekes compX pasiekiamumas yra 'Out Of Stock', skiltyje tabY prekes compY pasiekiamumas yra 'Pre-Order', nors visu prekiu statuso tikimasi 'In Stock'", "In Stock", "Out Of Stock");

//        tabletsPage.clickTabletsButton();
//        tabletsPage.clickTablet();
//        Assert.assertEquals("skiltyje tabX prekes compX pasiekiamumas yra 'Out Of Stock', skiltyje tabY prekes compY pasiekiamumas yra 'Pre-Order', nors visu prekiu statuso tikimasi 'In Stock'", "In Stock", "Pre-Order");
    }
}
