import org.junit.Assert;
import org.junit.Test;

public class TabletsPageTest extends BaseTest{
    TabletsPage tabletsPage = new TabletsPage(driver);

    @Test
    public void tabletsInStock(){
        tabletsPage.clickTabletsButton();
        tabletsPage.clickTablet();
        Assert.assertEquals("skiltyje Tablets prekes Samsung Galaxy Tab 10.1 pasiekiamumas yra 'Pre-Order', nors visu prekiu statuso tikimasi 'In Stock'", "In Stock", "Pre-Order");
    }
}
