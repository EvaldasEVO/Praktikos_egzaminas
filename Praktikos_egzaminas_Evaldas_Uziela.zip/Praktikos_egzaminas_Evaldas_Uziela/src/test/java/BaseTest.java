import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseTest {
    protected static WebDriver driver;

    @BeforeClass
    public static void setup() {
        System.setProperty("Webdriver.Chrome.Driver", "src/main/resources/chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://demo.opencart.com");
    }

    @AfterClass
    public static void tearDown(){
//     driver.quit();
    }
}
